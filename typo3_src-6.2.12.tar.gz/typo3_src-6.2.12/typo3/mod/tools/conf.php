<?php
$MLANG['default']['tabs_images']['tab'] = 'tool.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_admintools.xlf';
$MCONF['name'] = 'tools';
$MCONF['access'] = 'admin';
