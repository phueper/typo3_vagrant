<?php
// DO NOT REMOVE OR CHANGE THESE 3 LINES:
define('TYPO3_MOD_PATH', 'sysext/indexed_search/cli/');
$BACK_PATH = '../../../';
$MCONF['name'] = '_CLI_indexedsearch';
